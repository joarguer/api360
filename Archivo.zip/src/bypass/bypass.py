from hcapbypass import bypass
import sys

captcha_solved = bypass('antecedentes.policia.gov.co', sys.argv[1], True)
print(captcha_solved)